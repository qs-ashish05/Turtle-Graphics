# draw A use concept of triangle and linear angles
import turtle

# Create a turtle object
pen = turtle.Turtle()

# Draw the letter "A"
pen.left(60)
pen.forward(100)
pen.right(120)
pen.forward(100)
pen.backward(50)
pen.right(120)
pen.forward(50)

# Hide the turtle and display the result
pen.hideturtle()
turtle.done()
