# draw a cross

import turtle

pen = turtle.Turtle()

pen.left(45)
pen.forward(200)
pen.backward(100)

pen.left(90)
pen.forward(100)
pen.backward(200)

turtle.done()


# you may observe that at some places there are doubl lines we will learn about the goto command in next module to get rid of this