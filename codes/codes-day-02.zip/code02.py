# drawing circle using python 
import turtle

pen = turtle.Turtle()

pen.circle(100)