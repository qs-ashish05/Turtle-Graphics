# draw square 

import turtle

# for i in range(4):
#     turtle.forward(100)
#     turtle.left(90)



# with using pen object
pen = turtle.Turtle()

for i in range(4):
    pen.backward(100)
    pen.right(90)