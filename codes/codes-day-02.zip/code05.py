# writing using turtle 

import turtle

pen = turtle.Turtle()

pen.shape('circle')   

pen.penup()
pen.forward(50)         #  #  try with different values 
pen.color("blue")             #  try with different values 
pen.write("Aniket Gupta")
pen.backward(50)    # #  try with different values 
turtle.done()
