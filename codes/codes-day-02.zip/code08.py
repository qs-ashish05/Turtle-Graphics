import turtle

pen = turtle.Turtle()

for i in range(0,4):
    pen.circle(50)
    pen.right(90)


turtle.done()



# explain the program two times one without using for loop and one using for loop 
